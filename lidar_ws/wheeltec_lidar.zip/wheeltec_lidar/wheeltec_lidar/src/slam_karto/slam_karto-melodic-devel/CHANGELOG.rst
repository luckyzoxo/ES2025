^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package slam_karto
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.8.1 (2018-09-11)
------------------
* set C++11 if std not specified
  This is mainly for building on Lunar
* Contributors: Michael Ferguson

0.8.0 (2018-08-21)
------------------
* update maintainer email
* Merge pull request `#19 <https://github.com/ros-perception/slam_karto/issues/19>`_ from ros-perception/maintainer-add
  Adding myself as a maintainer for slam_karto
* Adding myself as a maintainer for slam_karto
* Merge pull request `#15 <https://github.com/ros-perception/slam_karto/issues/15>`_ from jasonimercer/lock-fix
  Fixed locks so they stay in scope until the end of the method.
* Fixed locks so they stay in scope until the end of the method.
* Merge pull request `#14 <https://github.com/ros-perception/slam_karto/issues/14>`_ from xpharry/indigo-devel
  modify for stage simulation
* modify for stage simulation
* Merge pull request `#9 <https://github.com/ros-perception/slam_karto/issues/9>`_ from hvpandya/patch-1
  Update karto_slam.launch
* Update karto_slam.launch
  package name must be slam_karto
* Contributors: Harsh Pandya, Jason Mercer, Luc Bettaieb, Michael Ferguson, xpharry

0.7.3 (2016-02-04)
------------------
* fixed the upside-down detection
* update maintainer email
* Contributors: Michael Ferguson, mgerdzhev

0.7.2 (2015-07-18)
------------------
* Added in parameter server settings for Mapper within slam_karto
* Contributors: Luc Bettaieb, Michael Ferguson

0.7.1 (2014-06-17)
------------------
* build updates for sba, fix install
* Contributors: Michael Ferguson

0.7.0 (2014-06-15)
------------------
* First release in a very, very long time.
* Catkinized, updated to work with catkinized open_karto and sba
* Contributors: Jon Binney, Michael Ferguson
