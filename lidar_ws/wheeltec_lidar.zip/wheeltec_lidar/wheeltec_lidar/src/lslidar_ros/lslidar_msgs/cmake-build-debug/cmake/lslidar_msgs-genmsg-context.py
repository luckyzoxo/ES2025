# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/msg/LslidarPacket.msg;/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/msg/LslidarPoint.msg;/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/msg/LslidarScan.msg;/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/msg/LslidarC16Sweep.msg;/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/msg/LslidarC32Sweep.msg;/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/msg/LslidarScanUnified.msg"
services_str = "/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/srv/lslidar_control.srv"
pkg_name = "lslidar_msgs"
dependencies_str = "std_msgs;sensor_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "lslidar_msgs;/home/ls-lqm/Desktop/c16_3.0/src/lslidar_ros/lslidar_msgs/msg;std_msgs;/opt/ros/kinetic/share/std_msgs/cmake/../msg;sensor_msgs;/opt/ros/kinetic/share/sensor_msgs/cmake/../msg;geometry_msgs;/opt/ros/kinetic/share/geometry_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/kinetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
